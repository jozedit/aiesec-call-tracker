import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { sheets } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export default async (req: Request) => {
  const url = new URL(req.url);

  if (req.method === "GET") {
    const id = url.searchParams.get("id");
    if (id) {
      const [sheet] = await db.select().from(sheets).where(eq(sheets.id, parseInt(id)));
      if (!sheet) return new Response("Not Found", { status: 404 });
      return Response.json(sheet);
    }
    const allSheets = await db
      .select({ id: sheets.id, name: sheets.name, rowCount: sheets.rowCount, createdBy: sheets.createdBy, createdAt: sheets.createdAt })
      .from(sheets)
      .orderBy(sheets.createdAt);
    return Response.json(allSheets);
  }

  if (req.method === "POST") {
    const { name, csvData, createdBy, rowCount } = await req.json();
    if (!name || !csvData || !createdBy) return new Response("Bad Request", { status: 400 });
    const [sheet] = await db.insert(sheets).values({ name, csvData, createdBy, rowCount: rowCount ?? 0 }).returning();
    return Response.json(sheet, { status: 201 });
  }

  if (req.method === "DELETE") {
    const id = url.searchParams.get("id");
    if (!id) return new Response("Bad Request", { status: 400 });
    await db.delete(sheets).where(eq(sheets.id, parseInt(id)));
    return new Response(null, { status: 204 });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/sheets",
};
