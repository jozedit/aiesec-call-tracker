CREATE TABLE "sheets" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"csv_data" text NOT NULL,
	"created_by" text NOT NULL,
	"row_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now()
);
